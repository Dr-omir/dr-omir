// Dr.Omir Firebase + Cloudinary configuration
// Firebase Web config is safe to use in frontend code. Security is enforced by
// Firebase Authentication + Firestore Rules, not by hiding these values.

export const firebaseConfig = {
  apiKey: "AIzaSyDeKJACHvMAlvAzrDqXy0V9dB9g8_dg2_0",
  authDomain: "sing-up-600dc.firebaseapp.com",
  projectId: "sing-up-600dc",
  storageBucket: "sing-up-600dc.firebasestorage.app",
  messagingSenderId: "17072814170",
  appId: "1:17072814170:web:757f9f7905ad8a5bb4c063",
  measurementId: "G-PXKPRRX9N2"
};

// Cloudinary unsigned upload configuration for documents/images.
// Create an Unsigned Upload Preset in Cloudinary and paste its name here.
export const cloudinaryConfig = {
  cloudName: "YOUR_CLOUDINARY_CLOUD_NAME",
  uploadPreset: "YOUR_UNSIGNED_UPLOAD_PRESET",
  uploadFolder: "dr-omir"
};
