# Dr.Omir — Firebase + YouTube + Cloudinary

This version keeps GitHub Pages as the frontend host, Firebase for authentication/database, YouTube for video embeds, and Cloudinary for document/image uploads.

## 1) Create Firebase project
1. Open Firebase Console and create a project.
2. Add a **Web App**.
3. The provided project already contains the Web App config you supplied in `firebase-config.js`.
4. In Authentication → Sign-in method, enable **Email/Password**.
5. Create a Firestore database.
6. In Firestore, create a collection named `admins`.
7. Create one document whose **Document ID is your Firebase user UID**. Add `active: true`.
   - First create your normal account from `auth.html`.
   - Open Firebase Console → Authentication → Users and copy your UID.
   - Create `admins/{that UID}` manually in Firestore.
8. Paste the contents of `firestore.rules` into Firestore Rules and publish.

## 2) Cloudinary for files
1. Create a Cloudinary account.
2. In Settings → Upload presets, create an **Unsigned** upload preset.
3. Put your Cloud Name and preset name in `firebase-config.js`.
4. Files uploaded from the Admin Dashboard are sent directly to Cloudinary; Firestore stores only their metadata and URL.

## 3) YouTube videos
Admin does not upload video files. The admin pastes a YouTube URL, for example:
`https://www.youtube.com/watch?v=VIDEO_ID`

The site automatically stores the video ID and renders it with a YouTube `<iframe>` embed.

## 4) Admin dashboard
Open `/admin.html` after logging in with the Firebase account whose UID exists in `admins`.

You can:
- add files
- add YouTube videos
- open content
- delete content from the website
- view registered users

Deleting a file from the dashboard removes its Firestore entry, but does not delete the Cloudinary asset. That prevents accidental permanent deletion and avoids needing a server-side secret. Orphaned Cloudinary assets can be cleaned up later from Cloudinary.

## 5) GitHub Pages
Upload all files to your repository, including:
- `index.html`
- `auth.html`
- `admin.html`
- `script.js`
- `firebase.js`
- `firebase-config.js`
- `style.css`
- `firestore.rules`
- `storage.rules`
- `assets/`

Then enable GitHub Pages from the repository's Settings → Pages.

## Important security note
The Firebase web config is not a password. Do not put Firebase service-account JSON, private keys, Cloudinary API secrets, or Firebase Admin SDK credentials in this repository. Admin authorization is enforced by Firestore Rules through the `admins/{uid}` document.
