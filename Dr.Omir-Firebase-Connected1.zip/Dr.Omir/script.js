import {
  watchAuth,
  isAdmin,
  isConfigured,
  getContent,
  logoutUser
} from './firebase.js';

const menuButton = document.querySelector('.menu-toggle');
const navLinks = document.querySelector('.nav-links');
if (menuButton) menuButton.addEventListener('click', () => {
  const active = navLinks.classList.toggle('active');
  menuButton.setAttribute('aria-expanded', active ? 'true' : 'false');
});
document.querySelectorAll('.nav-links a').forEach(link => link.addEventListener('click', () => navLinks?.classList.remove('active')));

const search = document.getElementById('resourceSearch');
const filter = document.getElementById('resourceFilter');
const emptyState = document.getElementById('emptyState');
let resources = [];

function renderResources() {
  const term = (search?.value || '').trim().toLowerCase();
  const category = filter?.value || 'all';
  const visible = resources.filter(item => {
    const text = `${item.title || ''} ${item.description || ''}`.toLowerCase();
    return (!term || text.includes(term)) && (category === 'all' || item.category === category);
  });
  const grid = document.getElementById('resourceGrid');
  grid.innerHTML = visible.map(item => {
    const ext = (item.format || item.fileName?.split('.').pop() || 'FILE').toUpperCase();
    return `<article class="resource-card reveal visible" data-title="${esc(item.title)}" data-category="${esc(item.category || 'other')}">
      <div class="resource-icon">${esc(ext.slice(0,5))}</div><div class="resource-body">
      <div class="resource-meta">${esc((item.category || 'OTHER').toUpperCase())} · ${esc(ext)}</div>
      <h3>${esc(item.title)}</h3><p>${esc(item.description || '')}</p>
      <div class="resource-actions"><a class="btn btn-primary small" href="${escAttr(item.url)}" target="_blank" rel="noopener">Open File</a><a class="text-link" href="${escAttr(item.url)}" target="_blank" rel="noopener">Open ↗</a></div>
      </div></article>`;
  }).join('');
  emptyState.style.display = visible.length ? 'none' : 'block';
}

function renderVideos(videos) {
  const grid = document.getElementById('videoGrid');
  grid.innerHTML = videos.map(item => `<article class="video-card reveal visible">
    <div class="video-embed"><iframe src="https://www.youtube.com/embed/${encodeURIComponent(item.videoId)}" title="${esc(item.title)}" loading="lazy" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div>
    <div class="video-content"><div class="resource-meta">VIDEO · YOUTUBE EMBED</div><h3>${esc(item.title)}</h3><p>${esc(item.description || '')}</p><a class="text-link" href="${escAttr(item.url)}" target="_blank" rel="noopener">Open on YouTube ↗</a></div>
  </article>`).join('') || '<div class="loading-card">No videos have been added yet.</div>';
}

async function loadContent() {
  if (!isConfigured) {
    document.getElementById('resourceGrid').innerHTML = '<div class="setup-notice">Firebase is not configured yet. Add your Firebase settings in <code>firebase-config.js</code>.</div>';
    document.getElementById('videoGrid').innerHTML = '<div class="setup-notice">Firebase is not configured yet. Add your Firebase settings in <code>firebase-config.js</code>.</div>';
    return;
  }
  try {
    resources = await getContent('file');
    const videos = await getContent('video');
    renderResources(); renderVideos(videos);
  } catch (error) {
    document.getElementById('resourceGrid').innerHTML = `<div class="setup-notice">Could not load resources: ${esc(error.message)}</div>`;
    document.getElementById('videoGrid').innerHTML = `<div class="setup-notice">Could not load videos: ${esc(error.message)}</div>`;
  }
}
search?.addEventListener('input', renderResources);
filter?.addEventListener('change', renderResources);

const authNav = document.getElementById('authNav');
watchAuth(async user => {
  if (!authNav) return;
  if (!user) {
    authNav.innerHTML = '<a class="btn btn-light small" href="auth.html">Login</a>';
    return;
  }
  const admin = await isAdmin(user.uid).catch(() => false);
  authNav.innerHTML = `<span class="user-greeting">Hi, ${esc(user.displayName || user.email?.split('@')[0] || 'User')}</span>${admin ? '<a class="btn btn-primary small" href="admin.html">Admin</a>' : ''}<button class="btn btn-light small" id="logoutButton">Logout</button>`;
  document.getElementById('logoutButton')?.addEventListener('click', async () => { await logoutUser(); location.reload(); });
});

document.getElementById('contactForm')?.addEventListener('submit', event => {
  event.preventDefault();
  const whatsappNumber = '201000000000';
  const name = document.getElementById('contactName').value.trim();
  const email = document.getElementById('contactEmail').value.trim();
  const message = document.getElementById('contactMessage').value.trim();
  const text = `Hello Dr. Omir,\n\nName: ${name}\nEmail: ${email}\n\nMessage:\n${message}`;
  window.open(`https://wa.me/${whatsappNumber}?text=${encodeURIComponent(text)}`, '_blank', 'noopener');
});

const observer = new IntersectionObserver(entries => entries.forEach(entry => { if (entry.isIntersecting) { entry.target.classList.add('visible'); observer.unobserve(entry.target); } }), { threshold: 0.08 });
document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
document.getElementById('year').textContent = new Date().getFullYear();
loadContent();

function esc(s='') { return String(s).replace(/[&<>\'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }
function escAttr(s='') { return esc(s); }
