import { initializeApp } from "https://www.gstatic.com/firebasejs/12.18.0/firebase-app.js";
import {
  getAuth,
  onAuthStateChanged,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  updateProfile
} from "https://www.gstatic.com/firebasejs/12.18.0/firebase-auth.js";
import {
  getFirestore,
  collection,
  addDoc,
  getDocs,
  getDoc,
  doc,
  deleteDoc,
  updateDoc,
  setDoc,
  query,
  orderBy,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.18.0/firebase-firestore.js";
import { firebaseConfig, cloudinaryConfig } from "./firebase-config.js";

const isConfigured = !Object.values(firebaseConfig).some(v => String(v).includes("YOUR_"));
const cloudinaryConfigured = !Object.values(cloudinaryConfig).some(v => String(v).includes("YOUR_"));

let app = null;
let auth = null;
let db = null;
if (isConfigured) {
  app = initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = getFirestore(app);
}

export { auth, db, isConfigured, cloudinaryConfigured };
export { collection, addDoc, getDocs, getDoc, doc, deleteDoc, updateDoc, setDoc, query, orderBy, serverTimestamp };

export function watchAuth(callback) {
  if (!auth) return callback(null);
  return onAuthStateChanged(auth, callback);
}

export async function registerUser(name, email, password) {
  const credential = await createUserWithEmailAndPassword(auth, email, password);
  await updateProfile(credential.user, { displayName: name });
  await setDoc(doc(db, "users", credential.user.uid), {
    uid: credential.user.uid,
    name,
    email,
    createdAt: serverTimestamp()
  });
  return credential.user;
}

export async function loginUser(email, password) {
  const credential = await signInWithEmailAndPassword(auth, email, password);
  return credential.user;
}

export async function logoutUser() {
  return signOut(auth);
}

export async function isAdmin(uid) {
  if (!db || !uid) return false;
  const snap = await getDoc(doc(db, "admins", uid));
  return snap.exists() && snap.data()?.active !== false;
}

export async function getContent(type) {
  if (!db) return [];
  const q = query(collection(db, "content"), orderBy("createdAt", "desc"));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(d => ({ id: d.id, ...d.data() })).filter(item => item.type === type);
}

export async function addContent(data) {
  if (!db) throw new Error("Firebase is not configured.");
  return addDoc(collection(db, "content"), { ...data, createdAt: serverTimestamp(), updatedAt: serverTimestamp() });
}

export async function updateContent(id, data) {
  return updateDoc(doc(db, "content", id), { ...data, updatedAt: serverTimestamp() });
}

export async function removeContent(id) {
  return deleteDoc(doc(db, "content", id));
}

export async function getAllUsers() {
  if (!db) return [];
  const snapshot = await getDocs(collection(db, "users"));
  return snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
}

export async function uploadToCloudinary(file) {
  if (!cloudinaryConfigured) throw new Error("Cloudinary is not configured yet.");
  const endpoint = `https://api.cloudinary.com/v1_1/${cloudinaryConfig.cloudName}/auto/upload`;
  const form = new FormData();
  form.append("file", file);
  form.append("upload_preset", cloudinaryConfig.uploadPreset);
  form.append("folder", cloudinaryConfig.uploadFolder);
  const response = await fetch(endpoint, { method: "POST", body: form });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error?.message || "Cloudinary upload failed.");
  return { url: result.secure_url, publicId: result.public_id, bytes: result.bytes, format: result.format };
}
